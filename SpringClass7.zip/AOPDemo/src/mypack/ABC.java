package mypack;

public interface ABC {

	void a();

	String b();

	void c(int x) throws Exception;

}