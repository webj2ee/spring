package mypack;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AroundProcessing implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation mi) 
			throws Throwable {
		String mname=mi.getMethod().getName()+"()";
		System.out.println("Around advice is applied on "+mname);
		System.out.println("Invoking the intercepted method...");
		Object r=mi.proceed();
		if(r !=null)
		{
			System.out.println(mname+" returned "+r);
			r ="failure";
			System.out.println("Return value is changed to failure");
			
		}
		System.out.println("Around advice completed.");
		return r;
	}

}
