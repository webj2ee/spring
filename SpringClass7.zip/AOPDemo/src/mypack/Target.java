package mypack;


public class Target implements ABC {

	
	@Override
	public void a()
	{
		
		System.out.println("a() of Target is invoked.");
	}
	
	@Override
	public String b()
	{
		System.out.println("b() of Target is invoked, returning success.");
		return "success";
	}
	
	@Override
	public void c(int x) throws Exception
	{
		System.out.println("c() of Target is invoked.");
		if(x < 0)
		{
			System.out.println("throwing exception...");
			throw(new Exception("Input must be > 0"));
		}
		
	}
}
