package mypack;

import java.lang.reflect.Method;

import org.springframework.aop.ThrowsAdvice;

public class ErrorProcessing implements ThrowsAdvice {

	public void afterThrowing(Exception e)
	{
		System.out.println("Throws Advice is applied.");
	}
	public void afterThrowing(Method m,
			Object args[], Object target,Exception e)
	{
		System.out.println("Throws Advice is applied on "+
	m.getName()+"() method.");
	}
}
