package mypack;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

public class PostProcessing implements AfterReturningAdvice {

	@Override
	public void afterReturning(Object returnValue,
			Method m, Object[] args, Object target) 
					throws Throwable {
	   String mname= m.getName()+"()";
	   System.out.println("After advice is applied on "
	   +mname);
	   if(returnValue !=null)
	   {
		   System.out.println(mname+" returned "+returnValue); 
		   returnValue="failre";
		   System.out.println("ReturnValue is changed to failure by the advice.");
	   }
	   else
	   {
		   System.out.println(mname+" returned nothing.");
	   }
	   System.out.println("After advice is completed.");
	}

}
