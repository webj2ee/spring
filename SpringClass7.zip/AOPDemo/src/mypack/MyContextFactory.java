package mypack;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MyContextFactory {

	private static ApplicationContext context;
	
	static
	{
		context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		
		
	}
	public static ApplicationContext getApplicationContext()
	{
		return context;
		
	}
	
}







