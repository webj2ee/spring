package mypack;

import org.springframework.beans.factory.BeanFactory;

public class PrimitiveValuedCollectionUser {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Obtaining the Trainer bean:");
		Trainer t = (Trainer)factory.getBean("tr");
		System.out.println("Trainer details:");
		System.out.println(t);
		
	}

}
