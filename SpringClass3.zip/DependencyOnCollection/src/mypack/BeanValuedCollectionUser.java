package mypack;

import org.springframework.beans.factory.BeanFactory;

public class BeanValuedCollectionUser {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Obtaining the Course bean:");
		Course c = (Course)factory.getBean("course");
		System.out.println("Course details:");
		System.out.println(c);
		
	}

}
