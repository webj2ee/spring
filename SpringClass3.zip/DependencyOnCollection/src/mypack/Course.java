package mypack;

import java.util.Iterator;
import java.util.List;

public class Course {

	private String name;
	private int fee;
	private List<Topic> topics;
	
	public Course() {
		super();
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public void setTopics(List<Topic> topics) {
		this.topics = topics;
	}
	public String toString()
	{
		StringBuilder str = new StringBuilder();
		str.append("Name: ").append(name).append("\n");
		str.append("Fee: ").append(fee).append("\n");
		str.append("Topic\tWeightage\n");
		Iterator<Topic> itr = topics.iterator();
		while(itr.hasNext())
			str.append(itr.next()).append("\n");
		
		return str.toString();
		
	}
	
}
