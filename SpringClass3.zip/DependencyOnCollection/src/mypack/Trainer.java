package mypack;

import java.util.Iterator;
import java.util.Set;

public class Trainer {

	// dependencies of the Trainer
	private String name;
	private Set<String> batches;
	
	public Trainer(String name, Set<String> batches) {
		super();
		this.name = name;
		this.batches = batches;
	}
	
	public String toString()
	{
		StringBuilder str = new StringBuilder();
		str.append("Name: ").append(name).append("\n");
		str.append("Batches:\n");
		Iterator<String> itr = batches.iterator();
		while(itr.hasNext())
			str.append(itr.next()).append("\n");
		
		return str.toString();
	}
	
}
