package mypack;

import java.util.*;


public class Test {

	int id;
	int passMarks;
	Map<Topic, Integer> questions;
	
	public Test(int id, int passMarks, Map<Topic, Integer> questions) {
		super();
		this.id = id;
		this.passMarks = passMarks;
		this.questions = questions;
	}
	public String toString()
	{
		StringBuilder str = new StringBuilder();
		str.append("Test Id: ").append(id).append("\n");
		str.append("Passing percentage: ").append(passMarks).append("\n");
		str.append("Topic wise questions count\n");
		Set<Map.Entry<Topic, Integer>> s= questions.entrySet();
		Iterator<Map.Entry<Topic, Integer>> itr = 
				s.iterator();
		
				while(itr.hasNext())
				{
			      Map.Entry<Topic, Integer> m = itr.next();		
			       str.append(m.getKey().getName()).append("\t");
			       str.append(m.getValue()).append("\n");
				}
		
		return str.toString();
		
	}
	
	
}
