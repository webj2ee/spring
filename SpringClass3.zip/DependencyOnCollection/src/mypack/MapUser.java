package mypack;

import org.springframework.beans.factory.BeanFactory;

public class MapUser {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Obtaining the Test bean:");
		Test t = (Test)factory.getBean("test");
		System.out.println("Test details:");
		System.out.println(t);
		
	}

}
