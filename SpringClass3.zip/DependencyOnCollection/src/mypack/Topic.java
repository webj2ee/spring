package mypack;

public class Topic {

	private String name;
	private int weightage;
	
	public Topic(String name, int weightage) {
		super();
		this.name = name;
		this.weightage = weightage;
	}
	
	public String getName() {
		return name;
	}

	public int getWeightage() {
		return weightage;
	}

	public String toString()
	{
		return name+"\t"+weightage;
		
	}
	
}
