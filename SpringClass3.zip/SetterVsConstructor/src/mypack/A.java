package mypack;

public class A {
 
	// Dependency of A
	private B b;

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
		System.out.println("B bean is injected into A.");
	}

	public A(B b) {
		this.b = b;
		System.out.println(
		"A bean is created and B bean is injected into it.");
	}

	public A() {
		System.out.println("A bean is created.");
		
	}
	
	
}
