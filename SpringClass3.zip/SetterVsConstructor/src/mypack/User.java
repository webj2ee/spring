package mypack;

import org.springframework.beans.factory.BeanFactory;

public class User {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println(
		"Requesting the creation of A bean through constructor injection...");
		A a1 = (A) factory.getBean("a1");
		System.out.println(
		"Requesting the creation of A bean through setter injection...");
		A a2 = (A) factory.getBean("a2");
	}

}
