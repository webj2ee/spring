package mypack;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

public class HonestConductor extends Conductor 
implements BeanFactoryAware
{

	//dependency
	private BeanFactory factory;
	
	@Override
	public Ticket getTicket() {
		
		return (Ticket)factory.getBean("ticket");
	}

	@Override
	public void setBeanFactory(BeanFactory factory) 
			throws BeansException {
		this.factory=factory;
		
	}
	

}
