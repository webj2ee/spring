package mypack;

import org.springframework.beans.factory.BeanFactory;

public class User {

	public static void main(String[] args) {
		//Obtaining BeanFactory i.e. IOC Container
		BeanFactory f=MyFactory.getBeanFactory();
	    System.out.println(
	    "Requesting conductor bean from the container...");
		Conductor c=(Conductor)f.getBean("con");
		System.out.println("Class of conductor object is: "
		+c.getClass().getName());
		System.out.println(
		"Requesting two tickets from the conductor...");
		Ticket t1=c.getTicket();
		Ticket t2=c.getTicket();
		System.out.println(
				"Details of the first ticket : "+t1);
		System.out.println(
				"Details of the second ticket : "+t2);
	}

}
