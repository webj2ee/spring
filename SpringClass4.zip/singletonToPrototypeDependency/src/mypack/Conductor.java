package mypack;

public abstract class Conductor {

	//lookup method
	public abstract Ticket getTicket();
}
