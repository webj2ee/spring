package mypack;

public class Ticket {

	private static int counter;
	private int no;
	
	public Ticket()
	{
		no=++counter;
	}
	public String toString()
	{
		return "It is ticket number "+no;
	}
}
