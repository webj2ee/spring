package mypack;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

public class PostProcessing implements AfterReturningAdvice {

	@Override
	public void afterReturning(Object returnedValue,
			Method m, Object[] args, Object target) throws Throwable {
		String mname=m.getName()+"() method ";
		System.out.println("After advice is applied on "
		+mname);
		if(returnedValue==null)
		{
			System.out.println(mname+"returned nothing.");
		}
		else
		{
			System.out.println(returnedValue +" is returned by "+mname);
			returnedValue="failure";
			System.out.println("return value is changed to failure by the after advice.");
		}
		System.out.println("After advice is completed.");
	}

}
