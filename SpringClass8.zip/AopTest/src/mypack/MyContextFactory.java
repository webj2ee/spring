package mypack;


import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MyContextFactory {

	private static ApplicationContext ctx;
	
	static
	{
		ctx=
		new ClassPathXmlApplicationContext(
			"applicationContext.xml");
		
	}
	public static ApplicationContext getApplicationContext()
	{
		return ctx;
	}
}










