package mypack;

public interface ABC {

	public void a();
	public String b();
	public void c(int x) throws Exception;
}
