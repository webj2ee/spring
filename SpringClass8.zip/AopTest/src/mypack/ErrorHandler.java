package mypack;

import java.lang.reflect.Method;

import org.springframework.aop.ThrowsAdvice;

public class ErrorHandler implements ThrowsAdvice {

	public void afterThrowing(Exception e)
	{
		System.out.println("Throws advice is applied.");
	}
	public void afterThrowing(
			Method m, Object args[], Object target,Exception e)
	{
	System.out.println("Throws advice is applied on "
	+m.getName()+"() method.");
	}
}
