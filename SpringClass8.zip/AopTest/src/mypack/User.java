package mypack;


import org.springframework.context.ApplicationContext;

public class User {

	public static void main(String[] args) {
		System.out.println("Application started.");
		ApplicationContext ctx=
			MyContextFactory.getApplicationContext();
	    System.out.println(
	    "Requesting proxy bean from the container...");
		ABC proxy=(ABC)ctx.getBean("proxy");
		System.out.println("Proxy obtained.");
		System.out.println("Invoking a() on proxy...");
		proxy.a();
		System.out.println("Invoking b() on proxy...");
		String str=proxy.b();
		System.out.println(str+" is returned by b() in main.");
		try
		{
			System.out.println("Invoking c() on proxy...");
			proxy.c(-5);
		}catch(Exception e)
		{
			System.out.println("Following exception is caught in main: "+e);
		}
		
		System.out.println("Application completed.");
	}

}
