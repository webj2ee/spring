package mypack;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;


public class AroundProcessing implements MethodInterceptor
{
	@Override
	public Object  invoke(MethodInvocation mi) throws Throwable
	{
		//pre processing if any
		String mname=mi.getMethod().getName()+"() method ";
		System.out.println("Around advice is applied on "
		+mname);
		//get the intercepted method invoked
		Object returnedValue=mi.proceed();
		//post processing if any
		if(returnedValue==null)
		{
			System.out.println(mname+"returned nothing.");
		}
		else
		{
			System.out.println(returnedValue +" is returned by "+mname);
			returnedValue="failure";
			System.out.println(
			"return value is changed to failure by the advice.");
		}
		System.out.println("Around advice is completed.");
		return returnedValue;
	}

}
