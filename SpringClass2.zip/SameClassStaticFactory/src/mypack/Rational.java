package mypack;

import java.util.Scanner;

public class Rational implements Number {

	private int p,q;
	
	public Rational(int p, int q) {
		super();
		this.p = p;
		this.q = q;
	}

	// Same class static factory method
	public static Number getNumber()
	{
		Scanner in = new Scanner(System.in);
		System.out.print("Enter Numerator: ");
		int p = in.nextInt();
		System.out.print("Enter Denomintor: ");
		int q = in.nextInt();
		return new Rational(p, q);
	}
	
	@Override
	public void display() {
		System.out.println(p+"/"+q);
		
	}

	@Override
	public Number add(Number n) {
		Rational r = (Rational)n;
		int p = this.p * r.q +this.q * r.p;
		int q = this.q * r.q;
		return new Rational(p, q);
	}

}








