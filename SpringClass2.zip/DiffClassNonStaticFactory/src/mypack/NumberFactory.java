package mypack;

import java.util.Scanner;

// Here the assumption is that we don't have the
// source code of Rational and Complex classes but
// state of their objects is to be initialized from
// the user's input.

public class NumberFactory {

	 private String numberType;
	 	 
	 
	public NumberFactory(String numberType) {
		
		this.numberType = numberType;
	}
	
	public Number getNumber()
	{
		if(numberType.equalsIgnoreCase("Complex"))
			return getComplex();
		else
			return getRational();
		
	}
	
	// Implementation specific methods for the 
	// internal use of the factory;
	
	private static Number getComplex()
			{
				Scanner in = new Scanner(System.in);
				System.out.print("Enter Real part: ");
				int r = in.nextInt();
				System.out.print("Enter Imaginary part: ");
				int i = in.nextInt();
				return new Complex(r, i);
			}
	
			private static Number getRational()
			{
				Scanner in = new Scanner(System.in);
				System.out.print("Enter Numerator: ");
				int p = in.nextInt();
				System.out.print("Enter Denomintor: ");
				int q = in.nextInt();
				return new Rational(p, q);
			}
	
}
