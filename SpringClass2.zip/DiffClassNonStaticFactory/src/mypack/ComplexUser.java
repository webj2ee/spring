package mypack;

import org.springframework.beans.factory.BeanFactory;

public class ComplexUser {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Obtaining two Complex objects:");
		Number n1 = (Number) factory.getBean("c");
		Number n2 = (Number) factory.getBean("c");
		System.out.print("First Number is: ");
		n1.display();
		System.out.print("Second Number is: ");
		n2.display();
		Number n3 = n1.add(n2);
		System.out.print("Their sum is: ");
		n3.display();
	}

}
