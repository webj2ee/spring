package mypack;

import java.util.Scanner;

// Here the assumption is that we don't have the
// source code of Rational and Complex classes but
// state of their objects is to be initialized from
// the user's input.

public class NumberFactory {

	
	// Different class static factory method
	public static Number getComplex()
			{
				Scanner in = new Scanner(System.in);
				System.out.print("Enter Real part: ");
				int r = in.nextInt();
				System.out.print("Enter Imaginary part: ");
				int i = in.nextInt();
				return new Complex(r, i);
			}
	// Different class static factory method
			public static Number getRational()
			{
				Scanner in = new Scanner(System.in);
				System.out.print("Enter Numerator: ");
				int p = in.nextInt();
				System.out.print("Enter Denomintor: ");
				int q = in.nextInt();
				return new Rational(p, q);
			}
	
}
