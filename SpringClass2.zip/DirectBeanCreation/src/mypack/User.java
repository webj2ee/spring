package mypack;

import org.springframework.beans.factory.BeanFactory;

public class User {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Requesting a1 bean:");
		AB a1 = (AB) factory.getBean("a1");
		System.out.println("Requesting a2 bean:");
		AB a2 = (AB) factory.getBean("a2");
		System.out.println("Requesting a3 bean:");
		AB a3 = (AB) factory.getBean("a3");
	}

}
