package mypack;

public class AB {

	private String a;
	private int b;
	
	private AB(String a, int b) {
		this.a = a;
		this.b = b;
		System.out.println(
		"AB bean is initialized by two "
		+ "parameterized constructor.");
	}
	
	private AB(int b) {
		this.b = b;
		System.out.println("AB bean is initialized by "
				+"int param constructor.");
	}
	private AB(String a) {
		this.a = a;
		System.out.println("AB bean is initialized by "
				+"String param constructor.");
	}
	
}
