package mypack;


public interface Number {

	public void display();
	public Number add(Number n);
}
