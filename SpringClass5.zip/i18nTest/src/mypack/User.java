package mypack;

import java.util.Locale;

import org.springframework.context.ApplicationContext;

public class User {

	public static void main(String[] args) {
		
		// Obtaining the reference of the ApplicationContext
		ApplicationContext ctx=
			MyContextFactory.getApplicationContext();
		//Requesting num1 bean
		Number n1 = (Number) ctx.getBean("num1");
		//Requesting num2 bean
		Number n2 = (Number) ctx.getBean("num2");
		//Obtaining sum of n1 & n2
		Number n3=n1.add(n2);
		//Requesting Locale bean
		Locale locale = (Locale) ctx.getBean("locale");
		System.out.print(
			ctx.getMessage("msg1", null, locale)+" :");
		n1.display();
		System.out.print(
				ctx.getMessage("msg2", null, locale)+" :");
		n2.display();
		System.out.print(
				ctx.getMessage("msg3", null, locale)+" :");
		n3.display();
		}

}








