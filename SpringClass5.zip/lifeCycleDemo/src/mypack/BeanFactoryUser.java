package mypack;

import org.springframework.beans.factory.*;

public class BeanFactoryUser {

	public static void main(String[] args) {
		System.out.println("Application Started.");
		BeanFactory factory = MyFactory.getBeanFactory();
		System.out.println("Requesting a1 bean:");
		A a1 = (A) factory.getBean("a1");
		/*System.out.println("Requesting a2 bean:");
		A a2 = (A) factory.getBean("a2");*/
		System.out.println("Application Completed.");
		
	}

}
