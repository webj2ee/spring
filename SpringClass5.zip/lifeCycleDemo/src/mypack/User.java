package mypack;

import org.springframework.beans.factory.xml.*;

public class User {

	public static void main(String[] args) {
		// Obtaining the reference of the BeanFactory
		XmlBeanFactory factory = 
		(XmlBeanFactory)MyFactory.getBeanFactory();
		System.out.println("Requesting a1 bean:");
		A a1 = (A) factory.getBean("a1");
		System.out.println("Requesting a2 bean:");
		A a2 = (A) factory.getBean("a2");
		System.out.println(
	   "Requesting the destruction of a2 bean...");
		factory.destroySingleton("a2");
	}

}
