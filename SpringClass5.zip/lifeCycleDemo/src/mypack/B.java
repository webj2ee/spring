package mypack;

public class B {

	public B() {
		System.out.println("B bean is created.");
	}

	
}
