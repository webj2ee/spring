package mypack;


import org.springframework.context.ApplicationContext;

public class AppContextUser {

	public static void main(String[] args) {
		System.out.println("Application Started.");
		ApplicationContext ctx=
				MyContextFactory.getApplicationContext();
		System.out.println("Requesting a1 bean:");
		A a1 = (A) ctx.getBean("a1");
		/*System.out.println("Requesting a2 bean:");
		A a2 = (A) ctx.getBean("a2");*/
		System.out.println("Application Completed.");
		
	}

}
