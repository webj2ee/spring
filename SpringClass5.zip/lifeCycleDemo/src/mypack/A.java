package mypack;

import org.springframework.beans.factory.*;

public class A implements BeanNameAware, 
InitializingBean, DisposableBean
{

	//Dependency of A
	private B b;
	private String name;
	
	
	public A() {
		System.out.println("A bean is created.");
	}
	public void setB(B b) {
		this.b = b;
		System.out.println("B bean is injected into A bean.");
	}
	
	@Override
	public void setBeanName(String name) {
		this.name = name;
		System.out.println("Name of the A bean is "+name);
		
	}
	@Override
	public void destroy() throws Exception 
	{
		System.out.println("Programmatic cleanup of "
	+name+" is performed.");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println(
			"Programmatic initialization of "
			+name+" is performed.");
		
	}
	public void postCreate()
	{
		System.out.println(
				"Declarative initialization of "
				+name+"is performed.");
	}
	public void preDestroy()
	{
		System.out.println("Declarative cleanup of "
				+name+" is performed.");
		
	}
	
}
