package service;


import org.springframework.transaction.annotation.Transactional;

import dao.AccountDao;

public class TransferServiceImpl implements 
TransferService {

	//Dependency of the Service
	AccountDao dao;
	
	public void setDao(AccountDao dao) {
		this.dao = dao;
	}



	@Transactional(rollbackFor={Exception.class})
	public void transfer(int src, int target, int amount)
			throws Exception {
		//persistence methods are invoked
		dao.withdraw(src, amount);
		dao.deposit(target, amount);
	}

}









