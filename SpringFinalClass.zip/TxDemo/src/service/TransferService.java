package service;

public interface TransferService {

	public void transfer(int src, int target, int amount)
	throws Exception;
}
