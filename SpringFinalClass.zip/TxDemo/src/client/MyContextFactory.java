package client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyContextFactory {

	private static ApplicationContext ctx;
	
	static
	{
		ctx=
		new ClassPathXmlApplicationContext("applicationContext.xml");
		
	}
	public static ApplicationContext getApplicationContext()
	{
		return ctx;
	}
}










