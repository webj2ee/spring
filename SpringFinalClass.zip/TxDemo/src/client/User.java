package client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import service.TransferService;

public class User {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter source A/C No.: ");
		int src=in.nextInt();
		System.out.print("Enter target A/C No.: ");
		int target=in.nextInt();
		System.out.print("Enter Amount to be transferred: ");
		int amount=in.nextInt();
		ApplicationContext ctx=
				MyContextFactory.getApplicationContext();
		TransferService ts= (TransferService)
				ctx.getBean("ts");
		try
		{
			System.out.println("Transferring...");
			ts.transfer(src, target, amount);
			System.out.println("Successfully transferred.");
		}catch(Exception e)
		{
			System.out.print("Transaction Failed because of: ");
			System.out.println(e.getMessage());
		}
	}

}
