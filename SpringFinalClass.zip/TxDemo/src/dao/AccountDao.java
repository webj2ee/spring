package dao;

import java.sql.*;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.DataSourceUtils;

public class AccountDao {

	//Dependency of the Dao
	DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	//Method to deposit amount to an account
	public void deposit(int acno, int amount) throws
	Exception
	{
		//Connection is obtained from the DataSourceUtils
		Connection con=
			DataSourceUtils.getConnection(dataSource);
		//PreparedStatement is created
		PreparedStatement stmt1=
			con.prepareStatement(
			"Select balance from Account where acno=?");
		//Account No. is set in the query
		stmt1.setInt(1, acno);
		//Query is executed
		ResultSet rset=stmt1.executeQuery();
		if(rset.next())
		{
			//A/C No is valid, amount is deposited
			PreparedStatement stmt2=
					con.prepareStatement(
					"update Account set balance=balance+? where acno=?");
			stmt2.setInt(1, amount);
			stmt2.setInt(2, acno);
			stmt2.executeUpdate();
		}
		else
		{
			//A/C is invalid, an exception is thrown.
			throw(new Exception(acno+" is an invalid account no."));
			
		}
		//connection is not explicity closed.
		//It will be closed by the TransactionManager
		//or the DataSourceUtils class.
	}
	
	//Method to withdraw amount from an account
		public void withdraw(int acno, int amount) throws
		Exception
		{
			//Connection is obtained from the DataSourceUtils
			Connection con=
				DataSourceUtils.getConnection(dataSource);
			//PreparedStatement is created
			PreparedStatement stmt1=
				con.prepareStatement(
				"Select balance from Account where acno=?");
			//Account No. is set in the query
			stmt1.setInt(1, acno);
			//Query is executed
			ResultSet rset=stmt1.executeQuery();
			if(rset.next())
			{
				//A/C is valid, its balance is checked.
				int bal=rset.getInt(1);
				if(bal >=amount)
				{	
				//A/C No is valid, amount is deposited
				PreparedStatement stmt2=
						con.prepareStatement(
						"update Account set balance=balance-? where acno=?");
				stmt2.setInt(1, amount);
				stmt2.setInt(2, acno);
				stmt2.executeUpdate();
				}
				else
				{
					//A/C doesn't have sufficient balance,
					//an exception is thrown.
					throw(new Exception(acno+" doesn't have sufficient balance."));
					
				}
			}
			else
			{
				//A/C is invalid, an exception is thrown.
				throw(new Exception(acno+" is an invalid account no."));
				
			}
			//connection is not explicity closed.
			//It will be closed by the TransactionManager
			//or the DataSourceUtils class.
		}
}










