package mypack;

public class User {

	public static void main(String[] args)
			throws Exception
	{
		System.out.println(
		"User started, obtaining a Printable object...");
		Printable p=ProxyFactory.getPrintable();
		System.out.println(
	"Printalbe obtained, invoking its print() method...");
		p.print();
	}

}
