package mypack;

import java.lang.reflect.Proxy;

public class ProxyFactory {

	public static Printable getPrintable() throws Exception
	{
		//Creating target object
		One target=new One();
		//Creating handler object
		PrintHandler handler=new PrintHandler(target);
		//Creating proxy
		Printable proxy=(Printable)
				Proxy.newProxyInstance(
						target.getClass().getClassLoader(),
						target.getClass().getInterfaces(),
						handler);
		//proxy is returned
		return proxy;
	}
}
