package mypack;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class PrintHandler implements InvocationHandler {

	//Data Member to store the reference of the target object
	private Object target;
		
	public PrintHandler(Object target) {
		this.target = target;
	}


	@Override
	public Object invoke(Object proxy, Method method,
				Object[] args) throws Throwable {
		
		//pre processing if any
		System.out.println("Pre processing can be applied to "
		+method.getName()+"() here.");
		//invoke the intercepted method
		Object rv=method.invoke(target, args);
		//post processing if any
		System.out.println("Post processing can be applied to "
				+method.getName()+"() here.");
				
		//return the method result
		return rv;
	}

}









