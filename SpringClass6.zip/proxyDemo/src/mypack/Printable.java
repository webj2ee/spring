package mypack;

public interface Printable {

	void print();

}