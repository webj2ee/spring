package mypack;

public class One implements Printable {

	@Override
	public void print()
	{
		System.out.println("print() of One is invoked.");
	}
}
