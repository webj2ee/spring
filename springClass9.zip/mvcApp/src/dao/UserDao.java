package dao;

import java.sql.*;

import javax.sql.DataSource;

import entity.User;

public class UserDao {

	//dependency of the Dao
	DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	//Method to save a user in the DB
	public void save(User user) throws Exception
	{
		Connection con=dataSource.getConnection();
		PreparedStatement stmt=con.prepareStatement(
		"insert into UserMaster (name,mailId,password) values(?,?,?)");
		stmt.setString(1, user.getName());
		stmt.setString(2, user.getMailId());
		stmt.setString(3, user.getPassword());
		stmt.executeUpdate();
		con.close();
	}
	
}










